
public class Generator {

	public static void main(String[] args) {
		// make 3 sets of words to choose from
		
		String [] firstWords = {"Good","Great", "Awesome","Terrible", "Disgusting", "Cool"};
		String [] secondWords = {"car", "phone", "speaker", "pencil" , "cup"} ;
		String [] thirdWords = {"John", "Jacob", "Mike", "Lucy", "Sarah"};
		
		// find out how many words are in each list
		
		int firstLength = firstWords.length;
		int secondLength = secondWords.length;
		int thirdLength = thirdWords.length;
		
		// generate 3 random numbers
		
		int rand1 = (int) (Math.random() * firstLength);
		int rand2 = (int) (Math.random() *secondLength);
		int rand3 = (int) (Math.random() * thirdLength); 
		// now build a phrase
	
	String phrase = firstWords[rand1] +  " "  +  secondWords[rand2] +  " "  +  thirdWords[rand3];
		
		// print out the phrase
	
	System.out.println("You have a " + phrase);
	}

}
